package task2;

import java.util.*;

public class TokenScanner {

    public static List<String> scanner(String input) {
        List<String> results = new ArrayList<>();
        
        // TODO: Add your code here
        
        return results;
    }

}
